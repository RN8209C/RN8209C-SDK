var a00146 =
[
    [ "__cr_flag", "a00146.html#ab98e73a38a7559b6b1b6ed52604603d4", null ],
    [ "__irq_masks", "a00146.html#a83f0c50a94c6687bea375ffb98d76f89", null ]
];