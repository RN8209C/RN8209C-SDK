var a00010 =
[
    [ "conn_cfg_tag", "a00010.html#a729266305dd3f35cbc298a0fffe36513", null ],
    [ "gap_conn_cfg", "a00010.html#afa5b646ebb1805e78d214a05d94bf20e", null ],
    [ "gatt_conn_cfg", "a00010.html#ac3e1ae1f9a5de1f5864739428c8f89f5", null ],
    [ "gattc_conn_cfg", "a00010.html#a7d6da7074357ac7b8c83ccd281e7c324", null ],
    [ "gatts_conn_cfg", "a00010.html#ab0943897fd2ff339c5b9125d015c2770", null ],
    [ "l2cap_conn_cfg", "a00010.html#a25261a5c421c074ed19394bfe9ee7ae6", null ],
    [ "params", "a00010.html#a21caf5ddf7d37ab38971f6c93a87d114", null ]
];