var a00008 =
[
    [ "gpiote_ch_id", "a00008.html#a2756839a926a4f2a6203cc2e2fb6b43c", null ],
    [ "lna_cfg", "a00008.html#a7b7b1dfb85c7b952307f9b9f07374e27", null ],
    [ "pa_cfg", "a00008.html#ac208c6f43d86a4189e9d5a12cb54243c", null ],
    [ "ppi_ch_id_clr", "a00008.html#a3aff181e10c1f989ec21e5011a0735c1", null ],
    [ "ppi_ch_id_set", "a00008.html#a3f03cc126554722a9ee9e06734a7c23e", null ]
];