var a00148 =
[
    [ "distance_us", "a00148.html#a34cb59c0e80b3698a3df265ab88b34b5", null ],
    [ "hfclk", "a00148.html#a23b414675dc9b11671f55601075f541d", null ],
    [ "length_us", "a00148.html#adf9603de0e582965d4bb1c0a42d8e88c", null ],
    [ "priority", "a00148.html#a18cc5dd5dc34877572e42ee8102fcb82", null ]
];