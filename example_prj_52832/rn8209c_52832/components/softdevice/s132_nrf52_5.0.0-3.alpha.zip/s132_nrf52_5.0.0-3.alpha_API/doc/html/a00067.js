var a00067 =
[
    [ "rx_phys", "a00067.html#ae32d4ca9e3f13b8a0519a667c14c6c86", null ],
    [ "tx_phys", "a00067.html#a965f80848d3b999ad1ebf06dad30c81c", null ]
];