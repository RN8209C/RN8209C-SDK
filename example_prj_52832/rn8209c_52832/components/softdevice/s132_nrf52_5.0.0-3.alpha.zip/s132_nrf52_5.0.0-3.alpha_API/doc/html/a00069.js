var a00069 =
[
    [ "active", "a00069.html#a7f3eda85d15916ad467a81faba18f076", null ],
    [ "adv_dir_report", "a00069.html#a28be4a91ff3816dce494a134fbc21b7c", null ],
    [ "interval", "a00069.html#a086b92604899521d85052d48d8552b7d", null ],
    [ "timeout", "a00069.html#a1ddedc25ebdb29351a7cbd0039ce6ed8", null ],
    [ "use_whitelist", "a00069.html#a4756538440b75bbb31a26e89478bdb5f", null ],
    [ "window", "a00069.html#a89a91dffe2c1b7edc26567c932a491b7", null ]
];