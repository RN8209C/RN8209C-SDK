var a00239 =
[
    [ "BLE_CONN_HANDLE_ALL", "a00239.html#ga75e3958065c393f536bd316877892997", null ],
    [ "BLE_CONN_HANDLE_INVALID", "a00239.html#gacf227b9b101dbcf08eccbbaba54e48f5", null ]
];