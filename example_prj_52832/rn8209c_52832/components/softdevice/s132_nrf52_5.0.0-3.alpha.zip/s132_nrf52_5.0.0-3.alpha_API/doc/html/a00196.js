var a00196 =
[
    [ "BLE_GAP_ADV_TYPE_ADV_DIRECT_IND", "a00196.html#gafefde83f6b598e7fb14868e0610bdf43", null ],
    [ "BLE_GAP_ADV_TYPE_ADV_IND", "a00196.html#ga6cc0db53453977ee0a31e59f07de2b86", null ],
    [ "BLE_GAP_ADV_TYPE_ADV_NONCONN_IND", "a00196.html#ga8c86ca45ebffc3938fd97f9556daa49c", null ],
    [ "BLE_GAP_ADV_TYPE_ADV_SCAN_IND", "a00196.html#ga594ca8490efef1702e8ccb6a28d2a1de", null ]
];