var a00038 =
[
    [ "effective_params", "a00038.html#a756e7a2a190d852a79c7002045c86023", null ]
];