var a00098 =
[
    [ "end_handle", "a00098.html#a7ef3ed6409b66e9b087a761bd6a2b747", null ],
    [ "start_handle", "a00098.html#a091b1b8aeda9dcc211ec3f44d6832c51", null ]
];