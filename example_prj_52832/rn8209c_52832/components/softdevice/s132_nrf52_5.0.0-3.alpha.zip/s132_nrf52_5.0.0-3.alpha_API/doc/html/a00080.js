var a00080 =
[
    [ "handle", "a00080.html#a2a5e5a0d6a57d4f05a886ab39db71506", null ],
    [ "uuid", "a00080.html#abe48b681935ca0e1a03ff85b3ea86219", null ]
];