var a00130 =
[
    [ "sdu_buf", "a00130.html#a7c6bb2940408762dc9f66e183cdfa346", null ],
    [ "sdu_len", "a00130.html#aa9a61f273bd931dfc2fa7e9f2533e4e2", null ]
];