var a00245 =
[
    [ "NRF_ERROR_BASE_NUM", "a00245.html#ga6657d0b1e8f050685ddf7d7c1d85c8e8", null ],
    [ "NRF_ERROR_SDM_BASE_NUM", "a00245.html#ga42709115c27b1a355561ae7060a6232f", null ],
    [ "NRF_ERROR_SOC_BASE_NUM", "a00245.html#ga27c2a0b7271420a6c3f7b186543ee227", null ],
    [ "NRF_ERROR_STK_BASE_NUM", "a00245.html#gaf090abe440a1752161646079114acaaf", null ]
];