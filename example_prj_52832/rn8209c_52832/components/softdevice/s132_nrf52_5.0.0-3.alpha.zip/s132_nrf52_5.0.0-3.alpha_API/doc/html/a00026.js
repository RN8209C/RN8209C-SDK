var a00026 =
[
    [ "rx_payload_limited_octets", "a00026.html#a39a06c10a15002060332d996c5b408e1", null ],
    [ "tx_payload_limited_octets", "a00026.html#a3467609bb7f3fb4c64f4bbb96990ed36", null ],
    [ "tx_rx_time_limited_us", "a00026.html#a7ffb03478453862a44ac65cf5fb92996", null ]
];