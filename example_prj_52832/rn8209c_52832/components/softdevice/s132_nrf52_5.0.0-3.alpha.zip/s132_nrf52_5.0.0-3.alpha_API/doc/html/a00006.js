var a00006 =
[
    [ "conn_handle", "a00006.html#ad7c997d8d0c6e0d3d24de3ecad426645", null ],
    [ "params", "a00006.html#a68370cb595b720c6b0b25eefdb3ea5dd", null ],
    [ "user_mem_release", "a00006.html#a21a25a889c763bceb2891d506331f484", null ],
    [ "user_mem_request", "a00006.html#a4d36c1c20a1ff24a62abba8ea73c74c8", null ]
];