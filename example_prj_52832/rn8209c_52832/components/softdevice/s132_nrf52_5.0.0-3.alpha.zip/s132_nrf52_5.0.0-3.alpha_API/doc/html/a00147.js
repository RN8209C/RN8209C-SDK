var a00147 =
[
    [ "hfclk", "a00147.html#a5d6e28106247179b7cde2e289f0f9c39", null ],
    [ "length_us", "a00147.html#a0495f3c5f7e2fd20663af081ca7e4c0b", null ],
    [ "priority", "a00147.html#ad45d8189eff4584a13d7069d3c877a55", null ],
    [ "timeout_us", "a00147.html#af56601d1b7ef92d49dbd1567bd1d39e0", null ]
];