var a00232 =
[
    [ "BLE_GATTS_ATTR_TAB_SIZE_DEFAULT", "a00232.html#ga3b329810a73308879c5c755ead002655", null ],
    [ "BLE_GATTS_ATTR_TAB_SIZE_MIN", "a00232.html#gab371a7dbc87e08383d3a85daa41f3bfc", null ]
];