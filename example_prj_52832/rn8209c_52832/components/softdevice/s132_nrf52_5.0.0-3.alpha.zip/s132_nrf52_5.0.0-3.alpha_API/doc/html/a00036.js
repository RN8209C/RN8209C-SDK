var a00036 =
[
    [ "conn_params", "a00036.html#a0b48983984c9a6eca0b81380f8af8a05", null ],
    [ "peer_addr", "a00036.html#a2107b9536488cbcb75ca3f059e5ab72e", null ],
    [ "role", "a00036.html#aa1a4e1a526f55c277154dd13cc09e774", null ]
];