var a00110 =
[
    [ "char_ext_props", "a00110.html#ac5e56544775870bc0dfcccbfe49546c5", null ],
    [ "char_props", "a00110.html#a3d9381741f1a0b9e3ca5e2a5ddeb6877", null ],
    [ "char_user_desc_max_size", "a00110.html#a5916d5b2468348a72e9dcbdfc8d09404", null ],
    [ "char_user_desc_size", "a00110.html#a1fdf0123a1e5ae6591be0e16879c7bf4", null ],
    [ "p_cccd_md", "a00110.html#a4f494bd8a75d2ccf90a2c8ef984e2268", null ],
    [ "p_char_pf", "a00110.html#a5df4352ff57b67dd10bdbbf64c4fdb79", null ],
    [ "p_char_user_desc", "a00110.html#a9ddbc4b4d561c032a3f32347c6ee5355", null ],
    [ "p_sccd_md", "a00110.html#af3b9236e9c489e8462306d97c502711a", null ],
    [ "p_user_desc_md", "a00110.html#a1c21d9bedc1defcbadee9fedea45c724", null ]
];