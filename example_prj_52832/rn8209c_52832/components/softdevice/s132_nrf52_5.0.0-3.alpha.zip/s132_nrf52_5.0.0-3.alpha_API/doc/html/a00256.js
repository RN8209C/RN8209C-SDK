var a00256 =
[
    [ "BLE Stack Enable", "a00257.html", null ],
    [ "Connection Configuration", "a00258.html", null ],
    [ "Interrupt-driven Event Retrieval", "a00259.html", null ],
    [ "Thread Mode Event Retrieval", "a00260.html", null ]
];