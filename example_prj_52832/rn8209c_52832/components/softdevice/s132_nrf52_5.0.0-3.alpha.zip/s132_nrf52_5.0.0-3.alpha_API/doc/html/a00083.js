var a00083 =
[
    [ "handle", "a00083.html#ada1f0c9228867fd73fd596d6d7241c67", null ],
    [ "uuid", "a00083.html#a039854704d107784b185fb11b00b1258", null ]
];