var a00178 =
[
    [ "Events, type definitions and API calls", "a00179.html", "a00179" ],
    [ "General error codes", "a00183.html", "a00183" ],
    [ "Module specific error code subranges", "a00184.html", "a00184" ],
    [ "Bluetooth status codes", "a00234.html", "a00234" ],
    [ "Module specific SVC, event and option number subranges", "a00237.html", "a00237" ],
    [ "Common types and macro definitions", "a00238.html", "a00238" ],
    [ "Message Sequence Charts", "a00256.html", "a00256" ],
    [ "SoftDevice Global Error Codes", "a00244.html", "a00244" ]
];