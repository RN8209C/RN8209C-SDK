var a00097 =
[
    [ "data", "a00097.html#a1691be986d4b730bbe2ccc3d40c5a088", null ],
    [ "handle", "a00097.html#ae8e1aafaf1cbc9b6f7b5fcd163dd5cac", null ],
    [ "len", "a00097.html#a323a6805f77fe47c890cde179ea2f674", null ],
    [ "offset", "a00097.html#a09d38782fd5d200a45146ae303614733", null ],
    [ "write_op", "a00097.html#a7cbd3dd7ab5f53b8f14e023b9c0c2db6", null ]
];