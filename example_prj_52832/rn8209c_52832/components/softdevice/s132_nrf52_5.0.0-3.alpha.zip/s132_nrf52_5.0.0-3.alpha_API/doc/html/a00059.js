var a00059 =
[
    [ "ch_map", "a00059.html#a71bb5ea1d8eecc86f819a1f5a3807818", null ],
    [ "conn_handle", "a00059.html#adbf93719ab5531a19758504bdeb6c469", null ]
];