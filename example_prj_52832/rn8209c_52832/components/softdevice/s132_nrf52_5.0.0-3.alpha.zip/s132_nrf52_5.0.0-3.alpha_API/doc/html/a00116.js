var a00116 =
[
    [ "handle", "a00116.html#a79c55f70b9d10f1e11b35bb2cc13fdbd", null ],
    [ "offset", "a00116.html#ac3c5c0c840625a5f28e90e9021eb2403", null ],
    [ "uuid", "a00116.html#a0f46ec246ade2872b88c0e02418808fa", null ]
];