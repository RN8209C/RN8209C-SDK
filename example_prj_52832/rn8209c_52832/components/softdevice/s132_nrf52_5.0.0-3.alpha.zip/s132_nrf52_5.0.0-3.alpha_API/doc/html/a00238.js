var a00238 =
[
    [ "Defines", "a00394.html", "a00394" ],
    [ "Structures", "a00395.html", "a00395" ]
];