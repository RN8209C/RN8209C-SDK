var a00102 =
[
    [ "flags", "a00102.html#ae9bf42dc0e530824c93ec423e6539220", null ],
    [ "handle", "a00102.html#a4b5cec7a8b33f482114d99026b2ee92d", null ],
    [ "len", "a00102.html#a068c40f218ed3932901529ac05b69c21", null ],
    [ "offset", "a00102.html#a85d01254a43068218061ab21acabe980", null ],
    [ "p_value", "a00102.html#acb007e4da5538ee061b33f65a7e289c0", null ],
    [ "write_op", "a00102.html#a2c42a23118699b0fab8f49f1d9b4b386", null ]
];