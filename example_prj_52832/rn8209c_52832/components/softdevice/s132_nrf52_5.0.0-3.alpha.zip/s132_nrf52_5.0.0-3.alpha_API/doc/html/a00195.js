var a00195 =
[
    [ "BLE_GAP_SCAN_TIMEOUT_MAX", "a00195.html#gaf9f03221006c77debca100889d5c59f4", null ],
    [ "BLE_GAP_SCAN_TIMEOUT_MIN", "a00195.html#ga4baffc2a25f63a57ddf48babb53f2b5a", null ]
];