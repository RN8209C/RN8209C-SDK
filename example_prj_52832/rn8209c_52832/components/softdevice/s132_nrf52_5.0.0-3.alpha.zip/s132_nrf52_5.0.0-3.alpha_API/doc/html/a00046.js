var a00046 =
[
    [ "peer_addr", "a00046.html#a04caea311ecf7e424375ed05e4075b20", null ],
    [ "rssi", "a00046.html#ae45b194594f6470b3191b7ff30a997a2", null ]
];