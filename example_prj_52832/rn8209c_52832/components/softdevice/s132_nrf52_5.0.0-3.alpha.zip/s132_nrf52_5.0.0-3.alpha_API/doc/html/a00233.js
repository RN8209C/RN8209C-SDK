var a00233 =
[
    [ "BLE_GATTS_HVN_TX_QUEUE_SIZE_DEFAULT", "a00233.html#gadeb57ec178918eea438c8b4a4944ebd2", null ]
];