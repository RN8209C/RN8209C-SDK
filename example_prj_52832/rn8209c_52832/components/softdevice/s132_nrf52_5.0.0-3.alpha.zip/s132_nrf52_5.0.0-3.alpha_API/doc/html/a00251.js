var a00251 =
[
    [ "__NRF_NVIC_APP_IRQS_0", "a00251.html#gaba5de891cdd369c5fc540172dec31e89", null ],
    [ "__NRF_NVIC_APP_IRQS_1", "a00251.html#gabdd12cd924ec1ea227b2a9d4d06b1438", null ],
    [ "__NRF_NVIC_ISER_COUNT", "a00251.html#ga487877945b5d9de06c09f4502898dd90", null ],
    [ "__NRF_NVIC_NVMC_IRQn", "a00251.html#gaf5d0e819980db5a60b98b5b3d7d1949f", null ],
    [ "__NRF_NVIC_SD_IRQS_0", "a00251.html#ga468d3a7a1fc64c089654d67254d036c2", null ],
    [ "__NRF_NVIC_SD_IRQS_1", "a00251.html#gab689c126d2d4efe4bde1fdceebb68d4d", null ]
];