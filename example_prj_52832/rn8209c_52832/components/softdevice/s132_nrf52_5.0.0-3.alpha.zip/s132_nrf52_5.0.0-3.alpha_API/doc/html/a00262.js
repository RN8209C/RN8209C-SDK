var a00262 =
[
    [ "Advertising", "a00263.html", null ],
    [ "Peripheral Connection Establishment and Termination", "a00264.html", null ],
    [ "Peripheral Connection Parameter Update", "a00265.html", null ],
    [ "RSSI for connections with event filter", "a00266.html", null ],
    [ "RSSI get sample", "a00267.html", null ],
    [ "Peripheral Security Procedures", "a00268.html", "a00268" ],
    [ "Scanning", "a00289.html", null ],
    [ "Central Connection Establishment and Termination", "a00290.html", null ],
    [ "Central Connection Parameter Update", "a00291.html", null ],
    [ "Central Security Procedures", "a00292.html", "a00292" ],
    [ "Central Connection Parameter Update on multiple links", "a00308.html", null ],
    [ "Central Control Procedure Serialization on multiple links", "a00309.html", null ],
    [ "Whitelist Sharing", "a00310.html", null ],
    [ "Privacy", "a00311.html", "a00311" ],
    [ "PHY Update Procedure", "a00318.html", "a00318" ],
    [ "Data Length Update Procedure", "a00321.html", null ]
];