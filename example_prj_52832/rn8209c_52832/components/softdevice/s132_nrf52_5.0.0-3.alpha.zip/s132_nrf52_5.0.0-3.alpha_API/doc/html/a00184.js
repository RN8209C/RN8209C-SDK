var a00184 =
[
    [ "NRF_GAP_ERR_BASE", "a00184.html#ga29249baa158d723505c601121d003034", null ],
    [ "NRF_GATTC_ERR_BASE", "a00184.html#ga200400dc8ad79918acee9cd038336165", null ],
    [ "NRF_GATTS_ERR_BASE", "a00184.html#ga7bc503f781e56a86cdd044d6043629b8", null ],
    [ "NRF_L2CAP_ERR_BASE", "a00184.html#ga82756b5d44b6b5757c3968513b4928ac", null ]
];