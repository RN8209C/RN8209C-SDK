var a00016 =
[
    [ "addr", "a00016.html#a49ff9794452fddf141087ac6df6d19d9", null ],
    [ "addr_id_peer", "a00016.html#a86722bfb476928c927ad97b32cda75ea", null ],
    [ "addr_type", "a00016.html#ad056845594972dd031a09700194d660c", null ]
];