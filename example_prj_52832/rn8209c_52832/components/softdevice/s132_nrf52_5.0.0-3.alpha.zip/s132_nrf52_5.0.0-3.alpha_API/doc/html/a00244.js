var a00244 =
[
    [ "Error Codes Base number definitions", "a00245.html", "a00245" ],
    [ "NRF_ERROR_BUSY", "a00244.html#ga5d2d8608f6d6a0329f58961a969e946e", null ],
    [ "NRF_ERROR_CONN_COUNT", "a00244.html#ga5fc58fcfed7097d1205c96acb5a66ab8", null ],
    [ "NRF_ERROR_DATA_SIZE", "a00244.html#ga4c61f2b54667506e90cc296721b2e658", null ],
    [ "NRF_ERROR_FORBIDDEN", "a00244.html#ga85125dae5d7e9d4b9964acbc13f641b3", null ],
    [ "NRF_ERROR_INTERNAL", "a00244.html#gadf8b0c33ea15352808e5ac7f69c2be8a", null ],
    [ "NRF_ERROR_INVALID_ADDR", "a00244.html#gabc562e4ddfe2f427666a3acdd0b469a3", null ],
    [ "NRF_ERROR_INVALID_DATA", "a00244.html#gaca6d57e218563351e7abdbdebb049f69", null ],
    [ "NRF_ERROR_INVALID_FLAGS", "a00244.html#ga10f61a8901fb865840da22a0792eca18", null ],
    [ "NRF_ERROR_INVALID_LENGTH", "a00244.html#ga59fe2a8fe184005aefa0835c7ff400fd", null ],
    [ "NRF_ERROR_INVALID_PARAM", "a00244.html#ga0a5831cf5092e0dd43a01869676ee076", null ],
    [ "NRF_ERROR_INVALID_STATE", "a00244.html#gaf0aff2ba7864b34a36b4a96986e1851e", null ],
    [ "NRF_ERROR_NO_MEM", "a00244.html#ga7ef4d466b79b31c6325f8b7af5d4f75f", null ],
    [ "NRF_ERROR_NOT_FOUND", "a00244.html#ga349d25ada15be023e0d507f45ada682c", null ],
    [ "NRF_ERROR_NOT_SUPPORTED", "a00244.html#gaacf52836cc3860c5ffd4e129f725f138", null ],
    [ "NRF_ERROR_NULL", "a00244.html#gaf6e08e45224ec612e6c95660eb1bcfa0", null ],
    [ "NRF_ERROR_RESOURCES", "a00244.html#gac94383171545e604e8347a044e8be13f", null ],
    [ "NRF_ERROR_SOFTDEVICE_NOT_ENABLED", "a00244.html#ga9a2af1a322a5dfb3bdb69e2aacd3bc27", null ],
    [ "NRF_ERROR_SVC_HANDLER_MISSING", "a00244.html#gacee74578161456da0759c7b80f55d2e0", null ],
    [ "NRF_ERROR_TIMEOUT", "a00244.html#gaf3ac440fa84dedc1a80baab36da36f80", null ],
    [ "NRF_SUCCESS", "a00244.html#ga7e6367efeaac363d8cf024940b4ec123", null ]
];