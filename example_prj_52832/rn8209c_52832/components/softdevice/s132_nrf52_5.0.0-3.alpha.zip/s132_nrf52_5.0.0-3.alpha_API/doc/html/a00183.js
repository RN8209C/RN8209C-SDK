var a00183 =
[
    [ "BLE_ERROR_INVALID_ATTR_HANDLE", "a00183.html#ga6346bb5ec3bcd4a25332dc782c1b7e01", null ],
    [ "BLE_ERROR_INVALID_CONN_HANDLE", "a00183.html#gabdc27cbc2ffac4a50640a0ce992c03af", null ],
    [ "BLE_ERROR_INVALID_ROLE", "a00183.html#ga1d92ffe1952beeff89e5bf768657460f", null ],
    [ "BLE_ERROR_NOT_ENABLED", "a00183.html#ga521db6a097589b80939d76cb453fad3c", null ]
];