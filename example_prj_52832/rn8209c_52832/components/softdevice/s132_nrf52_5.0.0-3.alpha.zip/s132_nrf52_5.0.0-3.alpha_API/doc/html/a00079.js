var a00079 =
[
    [ "handle", "a00079.html#a2f3376bb8111b1f924f19159e77b15e8", null ],
    [ "uuid", "a00079.html#ab7def3e5445f76eff9721ddb25649e09", null ]
];