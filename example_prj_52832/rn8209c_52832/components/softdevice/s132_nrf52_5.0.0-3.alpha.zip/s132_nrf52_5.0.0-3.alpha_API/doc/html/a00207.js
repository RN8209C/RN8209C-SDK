var a00207 =
[
    [ "BLE_GAP_PHY_1MBPS", "a00207.html#ga69dd87e677e5b1fc57b0874fe414e6d0", null ],
    [ "BLE_GAP_PHY_2MBPS", "a00207.html#ga8b773730dee79966b97bc62b5908ab7e", null ],
    [ "BLE_GAP_PHY_AUTO", "a00207.html#ga54b254b0493d050319d70a7a2f812aa4", null ],
    [ "BLE_GAP_PHY_CODED", "a00207.html#gaca98a1c4c8c2e2bc385cd81e9109068a", null ]
];