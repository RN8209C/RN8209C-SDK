var a00201 =
[
    [ "BLE_GAP_AUTH_KEY_TYPE_NONE", "a00201.html#ga869af3b1376d25aec9ae236e5772d7f1", null ],
    [ "BLE_GAP_AUTH_KEY_TYPE_OOB", "a00201.html#gaf9f173da3e04e3c8054cbbeaa488c3d1", null ],
    [ "BLE_GAP_AUTH_KEY_TYPE_PASSKEY", "a00201.html#ga914a323fb165826d2995ef9d79b341e6", null ]
];