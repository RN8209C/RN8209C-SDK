var a00021 =
[
    [ "device_name_cfg", "a00021.html#a595fa3ae67383df1959a77e90a819e96", null ],
    [ "role_count_cfg", "a00021.html#a5aacf299a27df0ae007af1a19e9de879", null ]
];