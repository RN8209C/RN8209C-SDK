var a00200 =
[
    [ "BLE_GAP_IO_CAPS_DISPLAY_ONLY", "a00200.html#ga4e2f9010ba35ab6488ec181f75786435", null ],
    [ "BLE_GAP_IO_CAPS_DISPLAY_YESNO", "a00200.html#ga88681e29c52a54de028e2ee164d2403b", null ],
    [ "BLE_GAP_IO_CAPS_KEYBOARD_DISPLAY", "a00200.html#gaacd3ccc6340303a1edcc7c718f3c1e6f", null ],
    [ "BLE_GAP_IO_CAPS_KEYBOARD_ONLY", "a00200.html#ga65df849ce31a65393bd89ef65a7575b4", null ],
    [ "BLE_GAP_IO_CAPS_NONE", "a00200.html#gad11df80d3ac9d375b320363694ec0a03", null ]
];