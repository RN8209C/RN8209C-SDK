var a00268 =
[
    [ "Peripheral Security Request", "a00269.html", null ],
    [ "Peripheral Legacy Pairing", "a00270.html", "a00270" ],
    [ "Peripheral LESC Pairing", "a00277.html", "a00277" ],
    [ "Pairing failure: Keysize out of supported range", "a00283.html", null ],
    [ "GAP Failed Pairing: Keysize too small", "a00284.html", null ],
    [ "Pairing failure: Pairing aborted by the application", "a00285.html", null ],
    [ "Pairing failure: Pairing failed from central", "a00286.html", null ],
    [ "Pairing failure: Timeout", "a00287.html", null ],
    [ "Peripheral Encryption Establishment using stored keys", "a00288.html", null ]
];