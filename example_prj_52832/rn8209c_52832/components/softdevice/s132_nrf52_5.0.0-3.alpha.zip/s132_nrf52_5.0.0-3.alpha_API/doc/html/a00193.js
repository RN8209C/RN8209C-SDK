var a00193 =
[
    [ "BLE_GAP_SCAN_INTERVAL_MAX", "a00193.html#ga074c4f810a17d67cf16c9c330f95ea52", null ],
    [ "BLE_GAP_SCAN_INTERVAL_MIN", "a00193.html#ga365a0563f4e49d868fb412509ce549ce", null ]
];