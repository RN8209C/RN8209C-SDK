var a00047 =
[
    [ "enc_info", "a00047.html#ad111ceb6802da6301dbe73a73b35a4a1", null ],
    [ "id_info", "a00047.html#a301c28abac3bf1f2f38d2b95854695cd", null ],
    [ "master_id", "a00047.html#ad0cc95342832dacb99b8b0daede5856c", null ],
    [ "peer_addr", "a00047.html#a2c9e328ee5b20afe64224e8d807e0015", null ],
    [ "sign_info", "a00047.html#ad6b652026333405eba289d528d220638", null ]
];