var a00192 =
[
    [ "BLE_GAP_ADV_INTERVAL_MAX", "a00192.html#gada06c7f328e5bcc50ce55f9f567129ca", null ],
    [ "BLE_GAP_ADV_INTERVAL_MIN", "a00192.html#gaf61691584387648b33a032c934bcd094", null ]
];