var a00151 =
[
    [ "len", "a00151.html#ae7fb48410ecb00dec1dca60d45cbc606", null ],
    [ "ptr1", "a00151.html#a03e88994f8127e877c2fd08800e64768", null ],
    [ "ptr2", "a00151.html#a3f670b76c31a7b6badf0bfadd1dc08b0", null ]
];