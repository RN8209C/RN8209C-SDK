var a00020 =
[
    [ "central_role_count", "a00020.html#a752484e8fd552b729f35609180e175d2", null ],
    [ "central_sec_count", "a00020.html#a1cc30212d93c36770aa9ee293520d763", null ],
    [ "periph_role_count", "a00020.html#ab1d09d29f5e563013f673182b8ec4c56", null ]
];