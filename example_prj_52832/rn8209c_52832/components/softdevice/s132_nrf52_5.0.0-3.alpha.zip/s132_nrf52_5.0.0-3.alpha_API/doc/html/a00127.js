var a00127 =
[
    [ "credits", "a00127.html#a7155f7b0cb31df2dde383b3a1f945ddd", null ],
    [ "peer_mps", "a00127.html#a0a73ed5ab9ec20c8ea4af6c1bf3916aa", null ],
    [ "tx_mps", "a00127.html#ad7a90c50a10a3f92f3ff7ce4e0e0f677", null ],
    [ "tx_mtu", "a00127.html#a5a4b7a0a4a9a74ca0d72e263ddb856a2", null ]
];