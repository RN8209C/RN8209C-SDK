var a00197 =
[
    [ "BLE_GAP_ADV_FP_ANY", "a00197.html#ga0b0393df73db101d6cbfaede2dbb7ea6", null ],
    [ "BLE_GAP_ADV_FP_FILTER_BOTH", "a00197.html#ga38ff579b96a5ad3abd2e4eb370dd1de6", null ],
    [ "BLE_GAP_ADV_FP_FILTER_CONNREQ", "a00197.html#gac37d0158c7458cb4250f9bdfba593858", null ],
    [ "BLE_GAP_ADV_FP_FILTER_SCANREQ", "a00197.html#gae2dcdb81f0e1e024b82b244058656d26", null ]
];