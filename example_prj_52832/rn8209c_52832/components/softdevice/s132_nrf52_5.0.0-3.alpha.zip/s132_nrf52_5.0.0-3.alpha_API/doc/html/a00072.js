var a00072 =
[
    [ "keys_own", "a00072.html#ae9731b27930d07a22cc5fdbca79c6c68", null ],
    [ "keys_peer", "a00072.html#ac345cdb950f249c06a03d74104777949", null ]
];