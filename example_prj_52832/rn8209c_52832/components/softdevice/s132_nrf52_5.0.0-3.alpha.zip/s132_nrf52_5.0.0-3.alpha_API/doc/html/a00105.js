var a00105 =
[
    [ "gatt_status", "a00105.html#a22732489c5283481acd5d8c883dd6819", null ],
    [ "len", "a00105.html#adc9081735142e83138dc91345caa7a39", null ],
    [ "offset", "a00105.html#ac6b4a578d5c850d4c5efb59e955ec557", null ],
    [ "p_data", "a00105.html#a761026004aaa7417330923edf5884f94", null ],
    [ "update", "a00105.html#a4216f6db5f93262ffd447ca9b4524646", null ]
];