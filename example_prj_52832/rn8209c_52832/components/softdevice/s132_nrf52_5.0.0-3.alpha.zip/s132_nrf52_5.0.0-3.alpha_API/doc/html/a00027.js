var a00027 =
[
    [ "max_rx_octets", "a00027.html#aa22a169b288955e244d1d7c401e6ea12", null ],
    [ "max_rx_time_us", "a00027.html#ae913899b74b6608f6885a1b104b6505b", null ],
    [ "max_tx_octets", "a00027.html#abfcf7a07a93b2ced099d724c507a6994", null ],
    [ "max_tx_time_us", "a00027.html#aa0e300c2d993251c7cc62f593d448f25", null ]
];