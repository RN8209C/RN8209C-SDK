var a00241 =
[
    [ "BLE_UUID_TYPE_BLE", "a00241.html#gae549d14b15783ba52dae5fdd5f9ac959", null ],
    [ "BLE_UUID_TYPE_UNKNOWN", "a00241.html#ga0dfc5e26324c8cd7226f3941acbf5b7e", null ],
    [ "BLE_UUID_TYPE_VENDOR_BEGIN", "a00241.html#ga7bdcaea9ea91ab20be755d78833da46d", null ]
];