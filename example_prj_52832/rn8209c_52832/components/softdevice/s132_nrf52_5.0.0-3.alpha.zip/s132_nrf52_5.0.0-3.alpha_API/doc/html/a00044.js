var a00044 =
[
    [ "rx_phy", "a00044.html#a91cfa48987170d60d0d650a6b191915b", null ],
    [ "status", "a00044.html#a88a9519abba82f618dd9189698eb367d", null ],
    [ "tx_phy", "a00044.html#a9dd201a30a75fdd064e490614987dd00", null ]
];