var a00128 =
[
    [ "ch_count", "a00128.html#ab0b0e4ae696dc4fd5271b86ea6cda0c5", null ],
    [ "rx_mps", "a00128.html#a42e75d04261b7e22147a32d8ef2c4a1b", null ],
    [ "rx_queue_size", "a00128.html#aaf42c72a2bc9c0aa8528b97240b0d9ed", null ],
    [ "tx_mps", "a00128.html#a91b1265748833883666f7a202ed8c7ef", null ],
    [ "tx_queue_size", "a00128.html#a99be5e7196666c10883e4464b6756b85", null ]
];