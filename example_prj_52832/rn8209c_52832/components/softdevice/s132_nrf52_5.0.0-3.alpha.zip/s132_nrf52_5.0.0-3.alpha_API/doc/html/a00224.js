var a00224 =
[
    [ "BLE_GATTS_FIX_ATTR_LEN_MAX", "a00224.html#ga4cf6efe8134f1f771c088ff7d4c1d79a", null ],
    [ "BLE_GATTS_VAR_ATTR_LEN_MAX", "a00224.html#gac2a12a8c74733f8a666083550b77dc09", null ]
];