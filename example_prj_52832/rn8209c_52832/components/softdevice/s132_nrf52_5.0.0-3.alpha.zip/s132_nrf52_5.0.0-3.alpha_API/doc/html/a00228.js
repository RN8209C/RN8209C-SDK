var a00228 =
[
    [ "BLE_GATTS_VLOC_INVALID", "a00228.html#ga0b0c153e71bddb01a4ba803a9110a6e4", null ],
    [ "BLE_GATTS_VLOC_STACK", "a00228.html#gaf51ee5f68c7eea401ee79cd250c1fb16", null ],
    [ "BLE_GATTS_VLOC_USER", "a00228.html#gaddb51f959e18123c5e215e22af0c31a9", null ]
];