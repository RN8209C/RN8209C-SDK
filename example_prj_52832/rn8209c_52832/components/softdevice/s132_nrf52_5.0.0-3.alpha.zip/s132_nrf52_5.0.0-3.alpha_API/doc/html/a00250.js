var a00250 =
[
    [ "Defines", "a00400.html", "a00400" ],
    [ "Variables", "a00401.html", "a00401" ],
    [ "SoftDevice NVIC internal functions", "a00402.html", null ],
    [ "SoftDevice NVIC public functions", "a00403.html", null ],
    [ "__sd_nvic_app_accessible_irq", "a00250.html#gaeb38dcaa0c4ae6a5e588590bc27819d1", null ],
    [ "__sd_nvic_irq_disable", "a00250.html#ga6befa49138823f0ec6572400cad08bbe", null ],
    [ "__sd_nvic_irq_enable", "a00250.html#gaad131d94ce361023b07ae1d3e3e56571", null ],
    [ "__sd_nvic_is_app_accessible_priority", "a00250.html#ga6ca528e83cd0bce219f2f2cc1c1893a7", null ],
    [ "sd_nvic_ClearPendingIRQ", "a00250.html#gaaab82d624bd21852288a3a6ad178cec7", null ],
    [ "sd_nvic_critical_region_enter", "a00250.html#gac3d990530890d81f388de7d507e170b8", null ],
    [ "sd_nvic_critical_region_exit", "a00250.html#ga7bcafdd2cd546560174d688fdbeda7dd", null ],
    [ "sd_nvic_DisableIRQ", "a00250.html#gae4a37ba1f3e17d21cb0c5360fbcbfdbf", null ],
    [ "sd_nvic_EnableIRQ", "a00250.html#ga02345fceba00ae870acefa61a322f5a2", null ],
    [ "sd_nvic_GetPendingIRQ", "a00250.html#gaef5164aef25dcabe8d58e4d0e8753995", null ],
    [ "sd_nvic_GetPriority", "a00250.html#gacfb8b86fa10fca62b0a30fdc49c3c78a", null ],
    [ "sd_nvic_SetPendingIRQ", "a00250.html#ga9b1ed18c3f856d229726c8eb1b8d676e", null ],
    [ "sd_nvic_SetPriority", "a00250.html#ga1f6d15a8df153e1f40ab27ffe049efd6", null ],
    [ "sd_nvic_SystemReset", "a00250.html#gad767473c9cfb8cf11c66f048e0d9eb5c", null ]
];