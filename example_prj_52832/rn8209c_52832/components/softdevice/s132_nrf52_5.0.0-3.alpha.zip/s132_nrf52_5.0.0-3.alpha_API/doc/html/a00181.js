var a00181 =
[
    [ "BLE_UUID_VS_COUNT_DEFAULT", "a00181.html#ga7681a25f4adabd8e368ba8671a270928", null ],
    [ "BLE_UUID_VS_COUNT_MAX", "a00181.html#ga0931f430ff6f39cd4bac86935569b933", null ]
];