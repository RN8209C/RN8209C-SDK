var a00206 =
[
    [ "BLE_GAP_DEVNAME_DEFAULT", "a00206.html#gad628e0c2245a27349fd218cb5f4ad6a7", null ],
    [ "BLE_GAP_DEVNAME_DEFAULT_LEN", "a00206.html#ga44d90ef5a469087fd881f4e838cb4f5a", null ],
    [ "BLE_GAP_DEVNAME_MAX_LEN", "a00206.html#gac2eb594dd57920a845941ba29990022d", null ]
];