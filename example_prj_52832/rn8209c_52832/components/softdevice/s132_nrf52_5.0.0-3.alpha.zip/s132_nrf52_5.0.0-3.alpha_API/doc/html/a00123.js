var a00123 =
[
    [ "params", "a00123.html#a402025fb277d33e15f1fa918bca15768", null ],
    [ "read", "a00123.html#a42cb7b43a91c07165f186df3f356f1c1", null ],
    [ "type", "a00123.html#a70efda4990b7c7e43bc7c0b1ae75c05e", null ],
    [ "write", "a00123.html#ab7d153f23f80575b3c529ac8fd7a8bea", null ]
];