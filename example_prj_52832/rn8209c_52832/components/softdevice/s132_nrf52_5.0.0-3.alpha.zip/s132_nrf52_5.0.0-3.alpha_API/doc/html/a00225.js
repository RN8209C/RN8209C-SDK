var a00225 =
[
    [ "BLE_GATTS_SRVC_TYPE_INVALID", "a00225.html#ga07c49b0b262d0b5bd709d282b659436d", null ],
    [ "BLE_GATTS_SRVC_TYPE_PRIMARY", "a00225.html#ga881b91f3ac789bf6fcefee7f815dcf7e", null ],
    [ "BLE_GATTS_SRVC_TYPE_SECONDARY", "a00225.html#ga1aa1898278ef4d0034858d752eac29b0", null ]
];