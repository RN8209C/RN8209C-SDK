var a00019 =
[
    [ "current_len", "a00019.html#a880a68d840f140408efa0503320d1e0d", null ],
    [ "max_len", "a00019.html#adaa0954db029e468732146a71f904566", null ],
    [ "p_value", "a00019.html#a67ba5064dbb9d2efcf58e29c5a421611", null ],
    [ "vloc", "a00019.html#a44d99a12d36514d68b71e15c8cc58fc8", null ],
    [ "write_perm", "a00019.html#a45dcadce6e2bfd67ac8a7cfc32c1622d", null ]
];