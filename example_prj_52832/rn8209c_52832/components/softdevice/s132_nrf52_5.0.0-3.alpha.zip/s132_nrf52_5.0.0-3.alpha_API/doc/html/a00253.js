var a00253 =
[
    [ "NRF_FAULT_ID_APP_MEMACC", "a00253.html#ga234338bb9d7e0f116a6e7112819cce6d", null ],
    [ "NRF_FAULT_ID_SD_ASSERT", "a00253.html#ga3884a419c2f90d294672e79711d009bf", null ]
];