var a00109 =
[
    [ "cccd_handle", "a00109.html#a7764817bceb1a13dde2a2d614aaff900", null ],
    [ "sccd_handle", "a00109.html#a0ebe446f83e8675203f224b1796939fa", null ],
    [ "user_desc_handle", "a00109.html#a263781c226cad6bfeeb894e133b19c55", null ],
    [ "value_handle", "a00109.html#a685865a59e73158fd661e9d64407e9d9", null ]
];