var a00255 =
[
    [ "NRF_CLOCK_LF_SRC_RC", "a00255.html#gac5af0958064c212f19db190b8ad1e7e6", null ],
    [ "NRF_CLOCK_LF_SRC_SYNTH", "a00255.html#ga814440bfe9a39511358d281a6211ccd2", null ],
    [ "NRF_CLOCK_LF_SRC_XTAL", "a00255.html#ga864bb1cea3623d59d8b84eee306b586c", null ]
];