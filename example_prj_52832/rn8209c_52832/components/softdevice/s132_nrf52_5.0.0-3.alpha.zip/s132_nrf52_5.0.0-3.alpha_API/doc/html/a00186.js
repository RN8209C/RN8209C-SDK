var a00186 =
[
    [ "BLE_GAP_ROLE_CENTRAL", "a00186.html#ga6b9440660a70146392d27c849431fadb", null ],
    [ "BLE_GAP_ROLE_INVALID", "a00186.html#ga8164b32f4fd65997d0523cd7c5735166", null ],
    [ "BLE_GAP_ROLE_PERIPH", "a00186.html#ga12e431897d73a3ce88fab8a4dbd90497", null ]
];