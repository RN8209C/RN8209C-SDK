var a00066 =
[
    [ "auth_payload_timeout", "a00066.html#a10dbd0b5810183cebb08aa079ac7d695", null ],
    [ "ch_map", "a00066.html#ac467d9642d6caa41dd4fdf8a4a3909d5", null ],
    [ "compat_mode_1", "a00066.html#ae8168ace040e71ec38084fc36e498f92", null ],
    [ "compat_mode_2", "a00066.html#a85aed2b1beaa3832498945af02b97ce7", null ],
    [ "local_conn_latency", "a00066.html#a1bb53c22c985681a03ee48b81498112c", null ],
    [ "passkey", "a00066.html#ada41fdfa545113ec48371bc74ec7aa9a", null ],
    [ "scan_req_report", "a00066.html#a67d4b73802048b55b9b9d65ad556ce8b", null ],
    [ "slave_latency_disable", "a00066.html#ac5677e85d26c255bbc01550535d885d1", null ]
];