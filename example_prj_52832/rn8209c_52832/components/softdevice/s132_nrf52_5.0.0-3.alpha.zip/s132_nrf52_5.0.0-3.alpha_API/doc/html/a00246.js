var a00246 =
[
    [ "SoftDevice Manager Error Codes", "a00247.html", "a00247" ],
    [ "Defines", "a00404.html", "a00404" ],
    [ "Enumerations", "a00405.html", "a00405" ],
    [ "Types", "a00406.html", "a00406" ],
    [ "Functions", "a00407.html", "a00407" ]
];