var a00068 =
[
    [ "p_device_irk", "a00068.html#a3e5f0a40f07ff9ebcdc76675dda2ec37", null ],
    [ "privacy_mode", "a00068.html#aa15818b2dc391db6bb0aabff9443f498", null ],
    [ "private_addr_cycle_s", "a00068.html#ad53a51d3051c12fd7f20f1b1295beca0", null ],
    [ "private_addr_type", "a00068.html#a7c3ff4fb9967a63ca2fb8829e9994983", null ]
];