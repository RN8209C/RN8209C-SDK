var a00136 =
[
    [ "ch_sdu_buf_released", "a00136.html#abf87d6a5e3ce55873ee3ab158574e41a", null ],
    [ "ch_setup", "a00136.html#ae35a2dea2b123896c3aaa49674478c68", null ],
    [ "ch_setup_refused", "a00136.html#a02fd28db700d2a55295a5afae22b5db4", null ],
    [ "ch_setup_request", "a00136.html#ab7e5f94c4cc32a7b1eacfd18f13f599e", null ],
    [ "conn_handle", "a00136.html#ab843f6e96efbaf3d2bffee8c92c62f1a", null ],
    [ "credit", "a00136.html#a226b27ffdf7cf03a7335dd0cc301b0e8", null ],
    [ "local_cid", "a00136.html#aca78ca1be0755b441d41a57e6685f969", null ],
    [ "params", "a00136.html#ac9beac1420f25dbd4bd49bb88bc2302d", null ],
    [ "rx", "a00136.html#a9556348814c8c1ca5c0e52a51dda67e6", null ],
    [ "tx", "a00136.html#a75c60941ac3f397d4a4bc6d21c01e351", null ]
];