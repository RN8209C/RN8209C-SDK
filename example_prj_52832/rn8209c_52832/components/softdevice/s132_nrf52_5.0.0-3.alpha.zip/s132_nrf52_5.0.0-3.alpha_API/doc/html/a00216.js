var a00216 =
[
    [ "BLE_GATT_HVX_INDICATION", "a00216.html#ga47f3222bcefb5eb4aed9a1dc7c796b1f", null ],
    [ "BLE_GATT_HVX_INVALID", "a00216.html#gae454efaf8b3f8c6871dca5d2db5ac724", null ],
    [ "BLE_GATT_HVX_NOTIFICATION", "a00216.html#gad5784996b45947f6d7f0cb81c9a4c9ed", null ]
];