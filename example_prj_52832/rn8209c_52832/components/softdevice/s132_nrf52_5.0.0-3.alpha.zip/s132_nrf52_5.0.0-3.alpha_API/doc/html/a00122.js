var a00122 =
[
    [ "handle", "a00122.html#a1a0552b266c588f67d3a6abc712bbfd6", null ],
    [ "offset", "a00122.html#a07033f6e0e63974b67627ae84bc12fc9", null ],
    [ "p_data", "a00122.html#ab9b0a2510366e748bd9d29980782a814", null ],
    [ "p_len", "a00122.html#a8b0b2dadb3128b0838c71235661f8174", null ],
    [ "type", "a00122.html#a2971c791821bea067f3bc2bbc35b9193", null ]
];