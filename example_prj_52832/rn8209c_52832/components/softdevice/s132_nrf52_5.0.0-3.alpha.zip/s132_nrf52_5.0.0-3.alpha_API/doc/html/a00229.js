var a00229 =
[
    [ "BLE_GATTS_AUTHORIZE_TYPE_INVALID", "a00229.html#ga156b817b68ec907affac6d5aa16f29aa", null ],
    [ "BLE_GATTS_AUTHORIZE_TYPE_READ", "a00229.html#gacd69638f1f1f3eddbedc59c530b946d8", null ],
    [ "BLE_GATTS_AUTHORIZE_TYPE_WRITE", "a00229.html#ga1b8036fd4c246ad2bb5696632761ab47", null ]
];