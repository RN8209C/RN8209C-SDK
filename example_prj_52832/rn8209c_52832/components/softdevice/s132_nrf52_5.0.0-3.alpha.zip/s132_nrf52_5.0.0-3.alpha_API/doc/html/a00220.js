var a00220 =
[
    [ "BLE_ERROR_GATTC_PROC_NOT_PERMITTED", "a00220.html#gaec4c26bdcc1235411c5feec6d38b3465", null ]
];