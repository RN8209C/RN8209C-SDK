var a00194 =
[
    [ "BLE_GAP_SCAN_WINDOW_MAX", "a00194.html#gaecdcf0491fde1b2c2c4082f7a2e81093", null ],
    [ "BLE_GAP_SCAN_WINDOW_MIN", "a00194.html#ga4015a62a4ffba084dfdf58c32989c7a8", null ]
];