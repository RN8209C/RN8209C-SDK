var a00065 =
[
    [ "conn_handle", "a00065.html#a4757dad45bf2f34652583355e761f6e8", null ],
    [ "disable", "a00065.html#a158bfaa2349dbb52914696c61288e217", null ]
];