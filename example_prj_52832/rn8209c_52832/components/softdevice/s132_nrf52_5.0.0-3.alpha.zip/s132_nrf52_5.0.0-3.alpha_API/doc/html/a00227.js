var a00227 =
[
    [ "BLE_GATTS_OP_EXEC_WRITE_REQ_CANCEL", "a00227.html#gae298558aca1af7f9dc5ce38268418059", null ],
    [ "BLE_GATTS_OP_EXEC_WRITE_REQ_NOW", "a00227.html#ga6b36a56316847e970cc728a68e5bb6f0", null ],
    [ "BLE_GATTS_OP_INVALID", "a00227.html#gaefcca583b8fedfba89e3e8864f5fb392", null ],
    [ "BLE_GATTS_OP_PREP_WRITE_REQ", "a00227.html#ga97ae5797d7a83c1df161626765ddb436", null ],
    [ "BLE_GATTS_OP_SIGN_WRITE_CMD", "a00227.html#ga0c61bfea52333d5d0b1f8ede31b3f8ee", null ],
    [ "BLE_GATTS_OP_WRITE_CMD", "a00227.html#gac567f652312a6f8bbb5e348f01ed3f77", null ],
    [ "BLE_GATTS_OP_WRITE_REQ", "a00227.html#ga52cba338739e55ac2843c2ef92bef44b", null ]
];