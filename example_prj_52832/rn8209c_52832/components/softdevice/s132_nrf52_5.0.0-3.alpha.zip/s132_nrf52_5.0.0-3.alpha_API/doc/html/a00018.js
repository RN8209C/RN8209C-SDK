var a00018 =
[
    [ "channel_mask", "a00018.html#ac7c7cd95220c033adf1288d095a5f1f7", null ],
    [ "fp", "a00018.html#a9e2d44610c896a2d1466eb293688f226", null ],
    [ "interval", "a00018.html#a289b288f81c56920fea9a6373697c7f3", null ],
    [ "p_peer_addr", "a00018.html#a19337364852d3508336d9f3eaf96d57b", null ],
    [ "timeout", "a00018.html#a81b240f5be7e508a84467b7ac2ff6d15", null ],
    [ "type", "a00018.html#aece8d919208244b8085f64b613708427", null ]
];